@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <div style="text-align: center;">
                    My name is Emman Y. Maraon, i'm from Mambaling Cebu City. I'm 23 years of age and i am the youngest of my family.
                    <br><br>
                    I love programming but sad to say, programming hates me. hahahaha. I love typing, making story in the computer, and search everything about the computer.
                    <br><br>
                    SELF is the ultimate wellness resource and community for all aspects of a person’s life. We recognize that wellness is as much about self-expression and self-compassion as it is about workout classes and healthy eating; that it’s not an all-or-nothing thing; and that every person’s individual goals for wellness are different, and that’s OK. We’re here to celebrate, motivate, entertain, and support people, and make them laugh, too.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
