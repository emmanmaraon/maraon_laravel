@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <div style="text-align: center;">
                    PHP2 is very interesting subject for me specially when is comes to laravel.<br>PHP2 teacher is Mr. Cataraja.<br>PHP2
                    is more about building a web page using MVC FRAMEWORK and it teach us RESTful API.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
