@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif

                    <div style="text-align: center;">Elementary: Mambaling Elementary School 2000-2006</div>
                    <div style="text-align: center;">High School: University of Cebu-Main Campus 2012-2014
                    <br>
                    CIT-U 2009-2011
                    Divisoria National High School-Leyte 2011-2012
                    </div>
                    <div style="text-align: center;">College: University of Cebu-Main Campus BSIT 2014-present</div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
